package com.iiht.opn.model;

public enum Roles {
	ROLE_USER, ROLE_ADMIN

}
