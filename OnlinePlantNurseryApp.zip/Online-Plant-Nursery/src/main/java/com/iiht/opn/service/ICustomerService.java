package com.iiht.opn.service;



import java.util.List;


import org.springframework.stereotype.Service;

import com.iiht.opn.model.Customer;


public interface ICustomerService {
	
	Customer addCustomer(Customer customer);

	Customer updateCustomer(Customer customer);

	Customer deleteCustomer(Customer customer);

	Customer viewCustomer(int customerId);

	List<Customer> viewAllCustomers();

	boolean validateCustomer(String userName, String password);
}