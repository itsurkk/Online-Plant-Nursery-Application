package com.iiht.opn.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iiht.opn.model.Plant;

@Repository

public interface IPlantRepository extends JpaRepository<Plant, Integer>{
	
	 public default Plant findByCommonName(String commonName) {
		 return new Plant();
	 }
	 
	 
	public default List<Plant> findAllByTypeOfPlant(String typeOfPlant){
		return new ArrayList<Plant>();
	}
	
	

}
